# reimed-frontend-full (GitHub-ready)
Páginas:
- index.html (atalhos)
- register/login/forgot/reset (fluxo de paciente com CPF)
- history.html (lista consultas do paciente)
- receptionist.html (escolhe especialidade)
- medico.html (mostra especialidade escolhida; digita 1,7s/palavra)

Configuração:
- `config.js` → `API_BASE` e `WORD_DELAY_MS` (pode alterar via `localStorage` também).
