
export const API_BASE = (localStorage.getItem('API_BASE') || 'https://remedy-queimadas-api.onrender.com');
export const WORD_DELAY_MS = Number(localStorage.getItem('WORD_DELAY_MS')||1700); // 1.7s/palavra
